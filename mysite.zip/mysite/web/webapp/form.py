from django import forms
from .models import *


class addform(forms.ModelForm):
  class Meta:
    model=AddProduct
    fields='__all__'