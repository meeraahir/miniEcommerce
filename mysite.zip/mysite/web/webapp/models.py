from django.contrib.auth.models import User
from django.db import models

# Create your models here.


class AddProduct(models.Model):
   SIZE_CHOICES = [
        ('small', 'Small'),
        ('medium', 'Medium'),
        ('large', 'Large'),
    ]

   AVAILABILITY_CHOICES = [
        ('inStock', 'In Stock'),
        ('outOfStock', 'Out of Stock'),
    ]
   product_name=models.CharField(max_length=255)
   product_description=models.CharField(max_length=100)
   product_price=models.IntegerField()
   # product_quantity=models.IntegerField()
   product_image=models.ImageField(upload_to='product/')
   product_image1 = models.ImageField(upload_to='product/')
   product_image2=models.ImageField(upload_to='product/')
   product_size = models.CharField(max_length=10, choices=SIZE_CHOICES)
   product_height=models.CharField(max_length=10)
   product_width = models.CharField(max_length=10)
   product_colour = models.CharField(max_length=10)
   product_stock=models.IntegerField()
   product_availability = models.CharField(max_length=10, choices=AVAILABILITY_CHOICES)


class  add_to_cart(models.Model):

    user=models.ForeignKey(User,on_delete=models.CASCADE)
    AddProduct=models.ForeignKey(AddProduct,on_delete=models.CASCADE)
    product_quantity = models.IntegerField()
    total_price=models.DecimalField(max_digits=10,decimal_places=2,blank=True,null=True)

    def save(self, *args, **kwargs):
        self.total_price = self.AddProduct.product_price * self.product_quantity
        super(add_to_cart, self).save(*args, **kwargs)


class Placeorder(models.Model):
     CHOICE=[
        ('cash','cash'),
        ('upi','upi'),
     ]
     first_name=models.CharField(max_length=10)
     last_name=models.CharField(max_length=10)
     email=models.EmailField()
     address=models.CharField(max_length=50)
     payment=models.CharField(max_length=10,choices=CHOICE)
     pin=models.IntegerField()

     def __str__(self):
         return f"{self.first_name} {self.last_name}"




