from django.urls import path

from webapp import views

urlpatterns = [
  path('',views.home,name='home'),
  path('login/',views.login,name='login'),
  path('registration/',views.registration,name='registration'),
  path('logout/',views.logout,name='logout'),
  path('addproduct/',views.addproduct,name='addproduct'),
  path('delete/<int:id>/', views.deleteProduct, name='delete'),
  path('updateProduct/<int:id>/',views.updateProduct,name='update'),
  path('productDetail/<int:id>/',views.productDetail,name='productDetail'),
  path('addTocart/<int:id>/',views.addTocart,name='addTocart'),
  path('cart/',views.view_cart,name='view_cart'),
  path('update_cart/<int:id>/', views.update_cart, name='update_cart'),
  path('remove_from_cart/<int:id>/', views.remove_from_cart, name='remove_from_cart'),
  path('placeorder/',views.placeorder,name='placeorder'),
  path('confirmorder/',views.confirmorder,name='confirmorder'),
  path('search/',views.search,name='search')


]