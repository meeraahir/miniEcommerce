from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import send_mail

from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.core.paginator import Paginator
from django.db import IntegrityError
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404


from web import settings
from .form import *



# Create your views here.
def home(request):
    return render(request,'home.html',{})

def login(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user=authenticate(username=username,password=password)

        if user is not None and User.is_authenticated:
            auth_login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Bad Credentials!')
            return redirect('home')
    return render(request,'login.html')

def registration(request):

    if request.method =='POST':

        username=request.POST['username']
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        email = request.POST['email']
        password = request.POST['password']
        cpassword = request.POST['conform password']

        if User.objects.filter(username=username).exists():
          messages.error(request,'Username is already exits! please try anotherUsername')
          return redirect('registration')

        if User.objects.filter(email=email).exists():
            messages.error(request,'Email is already exits! please try anotherEmail')
            return redirect('registration')

        if len(username) >10 :
            messages.error(request,'username must be under a 10 character')
            return redirect('registration')
        if password !=cpassword:
           messages.error(request,'password did not match')
           return redirect('registration')

        if not username.isalnum():
           messages.error(request,'Username must be alpha numeric')
           return redirect('registration')


        user=User.objects.create_user(username,email,password)
        user.first_name=firstname
        user.last_name=lastname
        user.save()
        messages.success(request,'Your account has been successfully created! we have sent you a confirmation email in order to activate your account.')

        #send Email code
        subject='Welcome to Ecommerce Website'
        message= (
            f"Hello {user.first_name},\n\n"
            "Welcome to Django!\n"
            "Thank you for visiting our website. We have also sent you a confirmation email. Please confirm your email address to activate your account.\n\n"
            "Thank you,\n"
            "Ahir Meera")
        from_email=settings.EMAIL_HOST_USER
        to_list=[user.email]
        send_mail(subject,message,from_email,to_list,fail_silently=True)
        #email.send()
        return redirect('login')
    return render(request,'registration.html')

def logout(request):
    auth_logout(request)
    # messages.success(request,'Logout Successfully !')
    return redirect('home')


@login_required(login_url='/login/')
def addproduct(request):

    if request.method =='POST':
        name=request.POST['productname']
        description = request.POST['description']
        price = request.POST['price']
        # quantity = request.POST['quantity']
        image = request.FILES['image']
        img1 = request.FILES['image1']
        img2 = request.FILES['image2']
        size = request.POST['size']
        height = request.POST['height']
        width = request.POST['width']
        colour = request.POST['colour']
        stock = request.POST['stock']
        availability = request.POST['availability']

        add=AddProduct.objects.create(
            product_name=name,
            product_description=description,
            product_price=price,
            # product_quantity=quantity,
            product_image=image,
            product_image1=img1,
            product_image2=img2,
            product_size=size,
            product_height=height,
            product_width=width,
            product_colour=colour,
            product_stock=stock,
            product_availability=availability
        )
        return redirect('addproduct')

    #read code
    product=AddProduct.objects.all()
    paginator=Paginator(product,3)

    page_number= request.GET.get('page')
    page_obj =paginator.get_page(page_number)
    return render(request,'addproduct.html',{'page_obj':page_obj})


def deleteProduct(request,id):
    p=AddProduct.objects.get(id=id)
    p.delete()
    return redirect('addproduct')

def updateProduct(request,id):
    up=AddProduct.objects.get(id=id)

    if request.method == 'POST':
        name = request.POST['productname']
        description = request.POST['description']
        price = request.POST['price']
        # quantity = request.POST['quantity']
        image = request.FILES.get('image',up.product_image)
        img1 = request.FILES.get('image1',up.product_image1)
        img2 = request.FILES.get('image2',up.product_image2)
        size = request.POST.get('size',up.product_size)
        height = request.POST['height']
        width = request.POST['width']
        colour = request.POST['colour']
        stock = request.POST['stock']
        availability = request.POST.get('availability',up.product_availability)

        up.product_name = name
        up.product_description = description
        up.product_price = price
        # up.product_quantity = quantity
        up.product_image = image
        up.product_image1 = img1
        up.product_image2 = img2
        up.product_size = size
        up.product_height = height
        up.product_width = width
        up.product_colour = colour
        up.product_stock = stock
        up.product_availability = availability

        up.save()
        return redirect('addproduct')
    return render(request,'updateProduct.html',{'up':up})


def productDetail(request,id):
    product=AddProduct.objects.get(id=id)
    return render(request,'productDetail.html',{'product':product})

@login_required
def addTocart(request,id):
     product = get_object_or_404(AddProduct, id=id)
     user = request.user

     cart_item, created = add_to_cart.objects.get_or_create(
         user=user,
         AddProduct=product,
         defaults={'product_quantity': 1,'total_price': product.product_price}
     )

     if not created:
         cart_item.product_quantity += 1
         cart_item.save()
     return redirect('view_cart')



    # return redirect('productDetail',id=id)


@login_required
def view_cart(request):
    user=request.user
    cart_item=add_to_cart.objects.filter(user=user)
    total_price=sum(item.total_price for item in cart_item)
    return render(request,'cart.html',{'total_price': total_price,'cart_items': cart_item})


def update_cart(request,id):
    if request.method == 'POST':
        cart_item= get_object_or_404(add_to_cart,id=id)
        new_quantity=request.POST.get('quantity')
        if new_quantity.isdigit() and int(new_quantity)>0:
            cart_item.product_quantity= int(new_quantity)
            cart_item.save()
            return redirect('view_cart')
        return redirect('view_cart')

def remove_from_cart(request,id):
    if request.method == 'POST':
        cart_item=get_object_or_404(add_to_cart,id=id)
        cart_item.delete()
    return redirect('view_cart')



def placeorder(request):
    if request.method == 'POST':
        fname = request.POST['firstname']
        lname = request.POST['lastname']
        email = request.POST['email']
        address = request.POST['address']
        payment = request.POST['payment']
        pin = request.POST['pin']

        po = Placeorder.objects.create(
            first_name=fname,
            last_name=lname,
            email=email,
            address=address,
            payment=payment,
            pin=pin
        )

        request.session['order_data'] = {
            'first_name': fname,
            'last_name': lname,
            'email': email,
            'address': address,
            'payment': payment,
            'pin': pin
        }

        return redirect('confirmorder')
    return render(request, 'placeorder.html')

def confirmorder(request):
    order_data = request.session.get('order_data', {})
    return render(request, 'confirmorder.html', {'order_data': order_data})


def search(request):
    return HttpResponse("This is search page")